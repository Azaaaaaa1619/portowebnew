document.addEventListener('DOMContentLoaded', function () {
  // Navbar scroll effect
  const nav = document.getElementById('navbarNav');

  window.addEventListener('scroll', function () {
    const scrollPosition = window.scrollY;
    if (scrollPosition >= 60) {
      nav.classList.add('nav-dark');
    } else {
      nav.classList.remove('nav-dark');
    }
  });

  // Lightbox zoom image
  const images = document.querySelectorAll('.zoomable-img');
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-img');

  if (images.length > 0 && lightbox && lightboxImg) {
    images.forEach(img => {
      img.addEventListener('click', () => {
        lightbox.style.display = 'flex';
        lightboxImg.src = img.src;
      });
    });

    lightbox.addEventListener('click', () => {
      lightbox.style.display = 'none';
    });
  }




  const btn = document.getElementById("letsTalkBtn");

  btn.addEventListener("click", function (e) {
    e.preventDefault();

    // Tambahkan animasi ke seluruh body atau kontainer utama
    document.body.classList.add("slide-out-right");

    // Delay sebelum berpindah halaman
    setTimeout(() => {
      window.location.href = "letstalk.html"; // ganti dengan URL halaman tujuan
    }, 1200); // harus sesuai durasi animasi
  });
});
